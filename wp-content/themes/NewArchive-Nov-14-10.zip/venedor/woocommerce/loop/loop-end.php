<?php
/**
 * Product Loop End
 *
 * @author 		WooThemes
 * @package 	WooCommerce/Templates
 * @version     2.0.0
 */
?>
<?php 
global $venedor_product_slider;
if ($venedor_product_slider) : ?>
</div>
<?php else : ?>
</ul>
<?php endif; ?>
</div>