<?php get_header() ?>

    <div id="content" class="no-content">
            
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="no-content-comment">
                        <h2><?php echo __('404', 'venedor') ?></h2>
                        <h3><?php echo __("It's not my fault buddy! <br/> I think you got lost.", 'venedor') ?></h3>
                    </div>
                </div>
            </div>
        </div>
    
    </div>

<?php get_footer() ?>